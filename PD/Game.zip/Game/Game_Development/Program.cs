﻿using System;
using System.Threading;

namespace Game_Development
{
    internal class Program
    {
        class PrintMaze
        {


            static void Main(string[] args)
            {
                Console.Clear();

                Maze g = new Maze();
                Player p = new Player(16,5);
                Enemy e = new Enemy(15, 20);

                g.printMaze();
                p.PrintPlayer();
                e.PrintEnemy();

                while (true)
                {
                    p.MovePlayer();
                    e.MoveEnemy();
                    Thread.Sleep(500);
                }
            }
        }
    }
}
