﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_Development
{
    class Player
    {
        public int Px;
        public int Py;

        public Player(int px, int py)
        {
            Px = px;
            Py = py;
        }

        public void PrintPlayer()
        {
            Console.SetCursorPosition(Px, Py);
            Console.Write('P');
        }

        public void ErasePlayer()
        {
            Console.SetCursorPosition(Px, Py);
            Console.Write(' ');
        }

        public void MovePlayer()
        {
            ErasePlayer();
            if (Px <= 60)
            {
                Px += 1;
            }
            if (Px == 61)
            {
                Px = 12;
            }
            PrintPlayer();
        }
    }
}