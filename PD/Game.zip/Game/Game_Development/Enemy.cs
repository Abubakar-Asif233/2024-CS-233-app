﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_Development
{
    class Enemy
    {
        public int Ex;
        public int Ey;

        public Enemy(int ex, int ey)
        {
            Ex = ex;
            Ey = ey;
        }

        public void PrintEnemy()
        {
            Console.SetCursorPosition(Ex, Ey);
            Console.Write('E');
        }

        public void EraseEnemy()
        {
            Console.SetCursorPosition(Ex, Ey);
            Console.Write(' ');
        }

        public void MoveEnemy()
        {
            EraseEnemy();
            if (Ex < 101)
            {
                Ex += 3;
            }
            if (Ex >= 102)
            {
                Ex = 15;
            }
            PrintEnemy();
        }
    }
}

