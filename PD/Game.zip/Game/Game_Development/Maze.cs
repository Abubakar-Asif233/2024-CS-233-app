﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_Development
{
    internal class Maze
    {
        public void printMaze()
        {
            Console.WriteLine("           _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _      ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          |                                                                                                                                                  |    ");
            Console.WriteLine("          | _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _|     ");
        }
    }
}

